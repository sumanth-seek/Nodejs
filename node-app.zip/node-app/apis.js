/**
 * @typedef PassengerRegistration
 * @property {string} qrcode.required
 * @property {string} name
 * @property {string} address
 * @property {string} mobile
 * @property {string} passport
 */